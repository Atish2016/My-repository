var app = angular.module('question', []);

app.controller('MainCtrl', function($scope) {
  
  $scope.questionForm = {
    
    questions : [
        {
          description: 'Which is you favorite Color',
          options: [
            {
              value : 'red',  counter : '2'
            },
            {
              value : 'blue',  counter : '1'
            },
           {
              value : 'Green',  counter : '3'
            },
            {
              value:'Burgundy',  counter : '1'
            }
            
            
          ]
        },
        {
          description: 'What is your favorite cuisine',
          options: [
           {
              value : 'Chinese', counter : '3'
            },
            {
              value : 'Mughlai',  counter : '2'
            },
           {
              value : 'South Indian',  counter : '1'
            },
            {
              value:'Italian',  counter : '2'
            }
            
           
          ]
        },
        {
          description: 'Which is your preferred Mobile OS?',
          options: [
           {
              value : 'Android',  counter : '3'
            },
            {
              value : 'iOS',  counter : '1'
            },
           {
              value : 'Windows',  counter : '2'
            },
            {
              value:'Firefox OS',  counter : '1'
            }
            
          ]
        
        }
      ]
  
  };
 
    
$scope.count=0;  
  $scope.result = [];
  $scope.sendAnswers = function(x) {
    $scope.answers = x;
    //do sth with answers..
    
  };
 
   
});
 