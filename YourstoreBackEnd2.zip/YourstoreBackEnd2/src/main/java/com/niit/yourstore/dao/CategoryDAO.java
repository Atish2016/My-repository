package com.niit.yourstore.dao;

import java.util.List;

import com.niit.yourstore.model.Category;

public interface CategoryDAO {
	
	public List<Category> list();
	
	public Category get(String categoryId);
	
	public void saveorupdate(Category category);
	
	public void delete(String categoryId);
	
	public Category getByName(String categoryName);

}
