package com.niit.yourstore.dao;

import java.util.List;

import com.niit.yourstore.model.Product;

public interface ProductDAO {

    public List<Product> list();
	
	public Product get(String productId);
	
	
	public void saveorupdate(Product product);
	
	public void delete(String productId);
	
}