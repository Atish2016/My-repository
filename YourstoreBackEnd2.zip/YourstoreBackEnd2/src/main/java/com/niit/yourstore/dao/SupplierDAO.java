package com.niit.yourstore.dao;

import java.util.List;

import com.niit.yourstore.model.Supplier;

public interface SupplierDAO {

    public List<Supplier> list();
	
	public Supplier get(String supplierId);
	
	public void saveorupdate(Supplier supplier);
	
	public void delete(String supplierId);
	
	public Supplier getByName(String supplierName);
	
}
