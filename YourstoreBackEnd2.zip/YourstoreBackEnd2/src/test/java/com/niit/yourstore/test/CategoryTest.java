package com.niit.yourstore.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.yourstore.dao.CategoryDAO;
import com.niit.yourstore.model.Category;

public class CategoryTest {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.yourstore");
		context.refresh();
		
		CategoryDAO categoryDAO=(CategoryDAO) context.getBean("categoryDAO");
		
		Category category=(Category) context.getBean("category");
		
		category.setCategoryId("C003");
		category.setCategoryName("Shoes");
		category.setDescription("Shoes Category");
		
		categoryDAO.saveorupdate(category);

	}

}
