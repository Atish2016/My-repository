package com.niit.yourstore.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.yourstore.dao.ProductDAO;
import com.niit.yourstore.model.Category;
import com.niit.yourstore.model.Product;

public class ProductTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.yourstore");
		context.refresh();
		
		ProductDAO productDAO =(ProductDAO) context.getBean("productDAO");
		Product product =(Product) context.getBean("product");
		
		
		
	//	System.out.println(c.getCategoryId());
		
		/*product.setProductId("PD_001");
		product.setProductName("shoes");
		product.setDescription("nice shoes");
		product.setPrice(2000f);
		product.setCategory_id("CG_003");
		product.setSupplier_id("SUP_001");
		*/
		
		
		//Category category=categoryDAO.getByName(product.getCategory().getCategoryName());
				
productDAO.saveorupdate(product);

	}

}
