package com.niit.yourstore.dao;

import java.util.List;

import com.niit.yourstore.model.Users;

public interface UsersDao {
	
	public List<Users> list();
	
	public Users get(String id);
	
	public void saveOrUpdate(Users users);
	
	public void delete(String id);
	
	

}
