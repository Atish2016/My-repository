package com.niit.yourstore.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.yourstore.model.Users;

@SuppressWarnings("deprecation")
@Repository
public class UsersDaoImpl implements UsersDao {
	@Autowired
	private SessionFactory sessionFactory;

	public UsersDaoImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public List<Users> list() {
		@SuppressWarnings({ "unchecked" })
		List<Users> usersList = (List<Users>) sessionFactory.getCurrentSession().createCriteria(Users.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		return usersList;
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public Users get(String id) {
		String hql = "from users where id=" + id;
		
		@SuppressWarnings("rawtypes")
		Query query=sessionFactory.getCurrentSession().createQuery(hql);
		List<Users> listUsers= (List<Users>) query.list();
		if (listUsers!=null && !listUsers.isEmpty()) {
		return listUsers.get(0);	
		}
		return null;
	}

	@Transactional
	public void saveOrUpdate(Users users) {
		sessionFactory.getCurrentSession().saveOrUpdate(users);
		
		
	}

	@Transactional
	public void delete(String id) {

		Users userToDelete = new Users();
		userToDelete.setId(id);
		sessionFactory.getCurrentSession().saveOrUpdate(id);
	}

}
