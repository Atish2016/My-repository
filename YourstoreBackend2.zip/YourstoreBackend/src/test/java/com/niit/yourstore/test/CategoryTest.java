package com.niit.yourstore.test;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.yourstore.dao.CategoryDao;
import com.niit.yourstore.model.Category;

public class CategoryTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.yourstore");
		context.refresh();
		
		Category c =(Category) context.getBean("category");
		CategoryDao categoryDao =(CategoryDao) context.getBean("categoryDao");
		
		
		c.setId("MOB_001");
		c.setName("Mobile");
		c.setDescription("Mobile product");
		
		
		
		
		categoryDao.saveOrUpdate(c);
		
		
		List<Category>  list =    categoryDao.list();
		
		for(Category cat : list)
		{
			System.out.println(cat.getId()  + ":" +  cat.getName()  + ":"+  cat.getDescription());
		}

	}

}
