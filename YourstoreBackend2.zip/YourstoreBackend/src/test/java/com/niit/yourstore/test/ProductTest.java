package com.niit.yourstore.test;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.yourstore.dao.ProductDao;
import com.niit.yourstore.model.Product;

public class ProductTest {
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.yourstore");
		context.refresh();
		
		Product p =(Product) context.getBean("product");
		ProductDao productDao =(ProductDao) context.getBean("productDao");
		
		
		p.setId("MOB_001");
		p.setName("Mobile");
		p.setDescription("Mobile product");
		p.setPrice(20000);
		p.setCategory_id("CAT_001");
		p.setSupplier_id("SUP_001");
		
		
		productDao.saveOrUpdate(p);
		
		
		List<Product>  list =    productDao.list();
		
		for(Product pro : list)
		{
			System.out.println(pro.getId()  + ":" +  pro.getName()  + ":"+  pro.getDescription());
		}

	}
}
